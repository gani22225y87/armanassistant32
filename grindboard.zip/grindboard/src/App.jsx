import { useEffect, useState } from "react";
import { onAuthStateChanged } from "firebase/auth";
import { auth } from "./firebase";
import Login from "./Login";
import Signup from "./Signup";
import Dashboard from "./Dashboard";
import Leaderboard from "./Leaderboard";
import "./index.css";

export default function App() {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState("login"); // login | signup | dashboard | leaderboard

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, (u) => {
      setUser(u);
      setLoading(false);
      if (u) setPage("dashboard");
    });
    return unsub;
  }, []);

  if (loading) return <div className="loading">Loading...</div>;

  if (!user) {
    if (page === "signup") return <Signup onSwitch={() => setPage("login")} />;
    return <Login onSwitch={() => setPage("signup")} />;
  }

  return (
    <div>
      <nav className="nav">
        <span className="nav-logo">⚡ GrindBoard</span>
        <div className="nav-links">
          <button
            className={page === "dashboard" ? "nav-btn active" : "nav-btn"}
            onClick={() => setPage("dashboard")}
          >
            Dashboard
          </button>
          <button
            className={page === "leaderboard" ? "nav-btn active" : "nav-btn"}
            onClick={() => setPage("leaderboard")}
          >
            Leaderboard
          </button>
          <button
            className="nav-btn logout"
            onClick={() => auth.signOut()}
          >
            Logout
          </button>
        </div>
      </nav>

      {page === "dashboard" && <Dashboard user={user} />}
      {page === "leaderboard" && <Leaderboard />}
    </div>
  );
}
