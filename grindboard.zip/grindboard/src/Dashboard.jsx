import { useState, useEffect, useRef } from "react";
import { doc, getDoc, updateDoc } from "firebase/firestore";
import { db } from "./firebase";

export default function Dashboard({ user }) {
  const [userData, setUserData] = useState(null);
  const [loading, setLoading] = useState(true);

  // Timer state
  const [running, setRunning] = useState(false);
  const [elapsed, setElapsed] = useState(0); // seconds
  const intervalRef = useRef(null);

  // Fitness state
  const [pushups, setPushups] = useState("");
  const [squats, setSquats] = useState("");
  const [fitnessMsg, setFitnessMsg] = useState("");

  // Load user data
  useEffect(() => {
    const load = async () => {
      const snap = await getDoc(doc(db, "users", user.uid));
      if (snap.exists()) setUserData(snap.data());
      setLoading(false);
    };
    load();
  }, [user.uid]);

  // Timer logic
  useEffect(() => {
    if (running) {
      intervalRef.current = setInterval(() => {
        setElapsed((e) => e + 1);
      }, 1000);
    } else {
      clearInterval(intervalRef.current);
    }
    return () => clearInterval(intervalRef.current);
  }, [running]);

  const formatTime = (secs) => {
    const m = String(Math.floor(secs / 60)).padStart(2, "0");
    const s = String(secs % 60).padStart(2, "0");
    return `${m}:${s}`;
  };

  const handleStopTimer = async () => {
    setRunning(false);
    if (elapsed === 0) return;

    const minutesStudied = Math.floor(elapsed / 60);
    if (minutesStudied === 0) {
      setElapsed(0);
      return;
    }

    const ref = doc(db, "users", user.uid);
    const snap = await getDoc(ref);
    const data = snap.data();
    const today = new Date().toISOString().split("T")[0];

    const { streak, lastActiveDate } = data;
    const newStreak = calcStreak(streak, lastActiveDate, today);

    const newStudyTotal = data.studyTimeTotal + minutesStudied;
    await updateDoc(ref, {
      studyTimeTotal: newStudyTotal,
      streak: newStreak,
      lastActiveDate: today,
    });

    setUserData((prev) => ({
      ...prev,
      studyTimeTotal: newStudyTotal,
      streak: newStreak,
      lastActiveDate: today,
    }));
    setElapsed(0);
  };

  const calcStreak = (currentStreak, lastActiveDate, today) => {
    if (!lastActiveDate) return 1;
    const last = new Date(lastActiveDate);
    const todayDate = new Date(today);
    const diffDays = Math.floor((todayDate - last) / (1000 * 60 * 60 * 24));
    if (diffDays === 0) return currentStreak; // same day
    if (diffDays === 1) return currentStreak + 1; // consecutive
    return 1; // streak broken
  };

  const handleAddFitness = async () => {
    const p = parseInt(pushups) || 0;
    const s = parseInt(squats) || 0;
    const total = p + s;
    if (total === 0) return;

    const ref = doc(db, "users", user.uid);
    const snap = await getDoc(ref);
    const data = snap.data();
    const today = new Date().toISOString().split("T")[0];

    const { streak, lastActiveDate } = data;
    const newStreak = calcStreak(streak, lastActiveDate, today);
    const newFitnessTotal = data.fitnessRepsTotal + total;

    await updateDoc(ref, {
      fitnessRepsTotal: newFitnessTotal,
      streak: newStreak,
      lastActiveDate: today,
    });

    setUserData((prev) => ({
      ...prev,
      fitnessRepsTotal: newFitnessTotal,
      streak: newStreak,
      lastActiveDate: today,
    }));

    setPushups("");
    setSquats("");
    setFitnessMsg(`+${total} reps added!`);
    setTimeout(() => setFitnessMsg(""), 2000);
  };

  if (loading) return <div className="loading">Loading dashboard...</div>;
  if (!userData) return <div className="loading">No user data found.</div>;

  const totalPoints = userData.studyTimeTotal + userData.fitnessRepsTotal;

  return (
    <div className="dashboard">
      <div className="welcome">
        <h2>Welcome back, <span className="accent">{userData.username}</span></h2>
      </div>

      {/* Stats Row */}
      <div className="stats-row">
        <div className="stat-card">
          <div className="stat-value">{userData.studyTimeTotal}</div>
          <div className="stat-label">Study Minutes</div>
        </div>
        <div className="stat-card">
          <div className="stat-value">{userData.fitnessRepsTotal}</div>
          <div className="stat-label">Fitness Reps</div>
        </div>
        <div className="stat-card">
          <div className="stat-value">🔥 {userData.streak}</div>
          <div className="stat-label">Day Streak</div>
        </div>
        <div className="stat-card highlight">
          <div className="stat-value">⚡ {totalPoints}</div>
          <div className="stat-label">Total Points</div>
        </div>
      </div>

      <div className="panels">
        {/* Study Timer */}
        <div className="panel">
          <h3 className="panel-title">📚 Study Timer</h3>
          <div className="timer-display">{formatTime(elapsed)}</div>
          <div className="timer-btns">
            {!running ? (
              <button className="btn-primary" onClick={() => setRunning(true)}>
                ▶ Start
              </button>
            ) : (
              <button className="btn-danger" onClick={handleStopTimer}>
                ⏹ Stop & Save
              </button>
            )}
            {!running && elapsed > 0 && (
              <button className="btn-ghost" onClick={() => setElapsed(0)}>
                Reset
              </button>
            )}
          </div>
          {!running && elapsed > 0 && (
            <p className="hint">Press Stop & Save to log your time</p>
          )}
        </div>

        {/* Fitness Tracker */}
        <div className="panel">
          <h3 className="panel-title">💪 Fitness Tracker</h3>
          <div className="fitness-inputs">
            <div className="input-group">
              <label>Push-ups</label>
              <input
                className="input"
                type="number"
                min="0"
                placeholder="0"
                value={pushups}
                onChange={(e) => setPushups(e.target.value)}
              />
            </div>
            <div className="input-group">
              <label>Squats</label>
              <input
                className="input"
                type="number"
                min="0"
                placeholder="0"
                value={squats}
                onChange={(e) => setSquats(e.target.value)}
              />
            </div>
          </div>
          <button className="btn-primary" onClick={handleAddFitness}>
            + Add Reps
          </button>
          {fitnessMsg && <p className="success-msg">{fitnessMsg}</p>}
        </div>
      </div>
    </div>
  );
}
