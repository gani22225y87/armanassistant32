import { useState, useEffect } from "react";
import { collection, getDocs, orderBy, query, limit } from "firebase/firestore";
import { db } from "./firebase";

export default function Leaderboard() {
  const [studyTop, setStudyTop] = useState([]);
  const [fitnessTop, setFitnessTop] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchLeaderboards = async () => {
      const studyQ = query(
        collection(db, "users"),
        orderBy("studyTimeTotal", "desc"),
        limit(10)
      );
      const fitnessQ = query(
        collection(db, "users"),
        orderBy("fitnessRepsTotal", "desc"),
        limit(10)
      );

      const [studySnap, fitnessSnap] = await Promise.all([
        getDocs(studyQ),
        getDocs(fitnessQ),
      ]);

      setStudyTop(studySnap.docs.map((d) => d.data()));
      setFitnessTop(fitnessSnap.docs.map((d) => d.data()));
      setLoading(false);
    };

    fetchLeaderboards();
  }, []);

  const medal = (i) => {
    if (i === 0) return "🥇";
    if (i === 1) return "🥈";
    if (i === 2) return "🥉";
    return `#${i + 1}`;
  };

  if (loading) return <div className="loading">Loading leaderboard...</div>;

  return (
    <div className="leaderboard-page">
      <h2 className="page-title">🏆 Leaderboard</h2>

      <div className="lb-panels">
        {/* Study Leaderboard */}
        <div className="lb-section">
          <h3 className="lb-title">📚 Study Time (minutes)</h3>
          <table className="lb-table">
            <thead>
              <tr>
                <th>Rank</th>
                <th>Username</th>
                <th>Minutes</th>
              </tr>
            </thead>
            <tbody>
              {studyTop.length === 0 ? (
                <tr>
                  <td colSpan="3" className="empty">No data yet</td>
                </tr>
              ) : (
                studyTop.map((u, i) => (
                  <tr key={u.uid} className={i < 3 ? "top-row" : ""}>
                    <td className="rank">{medal(i)}</td>
                    <td>{u.username}</td>
                    <td className="score">{u.studyTimeTotal}</td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* Fitness Leaderboard */}
        <div className="lb-section">
          <h3 className="lb-title">💪 Fitness Reps</h3>
          <table className="lb-table">
            <thead>
              <tr>
                <th>Rank</th>
                <th>Username</th>
                <th>Reps</th>
              </tr>
            </thead>
            <tbody>
              {fitnessTop.length === 0 ? (
                <tr>
                  <td colSpan="3" className="empty">No data yet</td>
                </tr>
              ) : (
                fitnessTop.map((u, i) => (
                  <tr key={u.uid} className={i < 3 ? "top-row" : ""}>
                    <td className="rank">{medal(i)}</td>
                    <td>{u.username}</td>
                    <td className="score">{u.fitnessRepsTotal}</td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
